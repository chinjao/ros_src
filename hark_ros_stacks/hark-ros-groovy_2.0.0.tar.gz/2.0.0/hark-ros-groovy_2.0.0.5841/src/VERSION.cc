#include <Object.h>
#include "../config.h"
using namespace FD;
DECLARE_MODULE_VERSION(HARKROS, SVN_REVISION, TAGS_VERSION);
